package com.company.rewards.util;

public class RewardsUtilTest {

    /*
    @Test
    public void testIsRange1(){
        Double amt = 99d;
        boolean actual = RewardsUtil.isRange1(amt);
        assertEquals( true, actual);

    }

    public void testIsRange1Scenario2(){
        Double amt = 199d;
        boolean actual = RewardsUtil.isRange1(amt);
        assertEquals( false, actual);

    }

    public void testIsRange2(){
        Double amt = 199d;
        boolean actual = RewardsUtil.isRange2(amt);
        assertEquals( true, actual);

    }

    */

}
