package com.comp.project.asset;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
